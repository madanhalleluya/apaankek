<?php

// HARGAI PEMBUAT SCRIPT. JANGAN UBAH COPYRIGHTNYA

$emailku = "gguncheck257@gmail.com"; // Ganti dengan email kalian


// SCRIPT BY ZENCODEX
// GABUNG GRUP https://t.me/zencodex UNTUK DAPAT SCRIPT TERBARU
