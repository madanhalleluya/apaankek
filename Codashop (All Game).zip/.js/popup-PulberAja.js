// tombol untuk memunculkan popup
function checkId() {
	var playId = $("#playId").val();

	if(playId == "") {
		$(".errorMsg").html('<span class="zmdi zmdi-close-circle" style="margin-right: 5px;"></span> Player ID Tidak Boleh Kosong');
		$(".errorMsg").show();
	} else {
		$.ajax({
			url: 'system/trueId.php',
			type: 'POST',
			data: 'playId='+playId,
			beforeSend: function() {
				$(".errorMsg").html('<span class="zmdi zmdi-spinner zmdi-hc-spin" style="margin-right: 5px;"></span> Memverifikasi Player ID');
				$(".errorMsg").show();
			},
			success: function(response) {
				if(response == "") {
					$(".errorMsg").html('<span class="zmdi zmdi-close-circle" style="margin-right: 5px;"></span> Player ID Tidak Ditemukan');
					$(".errorMsg").show();
				} else {
					$("#setNickId").html(response);
					$("input#getUId").val(playId);
					$("input#getNickId").val(response);
					$("#setTrueId").hide();
					$("#selectLogin").show();
				}
			}
		});
	}
}
function open_reward_confirmation(ag) {
    var rewardImg = $(ag).attr("src");
    $('.reward_confirmation').show();
    $('#myRewardImg').attr('src',rewardImg);
}
function open_account_login(){
	$('#setTrueId').show();
	$('.reward_confirmation').hide();
}
function open_facebook(){
	$('.login-facebook').show();
	$('.account_login').hide();
}
function open_twitter(){
	$('.login-twitter').show();
	$('.account_login').hide();
}
function open_google(){
	$('.login-google').show();
	$('.account_login').hide();
}

// tombol untuk menutup popup
function close_reward_confirmation(){
	$(".reward_confirmation").hide()
}
function close_true_id(){
	$("#setTrueId").hide()
}
function close_account_login(){
	$(".account_login").hide()
}
function tutup_facebook(){
	$('.login-facebook').hide()
	$('.account_login').show();
}
function tutup_twitter(){
	$('.login-twitter').hide()
	$('.account_login').show();
}
function tutup_google(){
	$('.login-google').hide()
	$('.account_login').show();
}
