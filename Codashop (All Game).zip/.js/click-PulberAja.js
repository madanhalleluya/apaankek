var buka = new Audio();
buka.src = "http://k.top4top.io/m_1794qgu8r0.mp3";

var tutup = new Audio();
tutup.src = "http://l.top4top.io/m_179468zvk1.mp3";