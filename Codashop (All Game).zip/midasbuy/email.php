<?php
$emailku = 'agit3016@gmail.com'; 
?>